module

public import Mathlib.NumberTheory.ArithmeticFunction.Misc
public import OddPerfect.TothTrillion

public section

namespace DescartesNumber

/-- Tóth's cofactor bound for a Descartes factorization. -/
theorem descartes_non_example_factor_gt_ten_pow_twelve (m w : ℕ)
    (hf : (1 < w ∧ ¬ w.Prime) ∧ Odd (m * w) ∧ Nat.Coprime m w ∧
      ArithmeticFunction.sigma 1 m * (w + 1) = 2 * m * w)
    (hne : m * w ≠ 198585576189) : 10 ^ 12 < m := by
  obtain ⟨⟨hw, hnp⟩, hodd, hcop, hbal⟩ := hf
  obtain ⟨hm, hwo⟩ := Nat.odd_mul.mp hodd
  exact OddPerfect.trillion_lt_spoof_cofactor
    ⟨hm, hwo, hw, hnp, hcop, by simpa only [Nat.mul_assoc] using hbal⟩ hne

end DescartesNumber
