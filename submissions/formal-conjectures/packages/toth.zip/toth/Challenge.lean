module

public import Mathlib.NumberTheory.ArithmeticFunction.Misc

public section

namespace DescartesNumber

/-- Tóth's cofactor bound for a Descartes factorization. -/
theorem descartes_non_example_factor_gt_ten_pow_twelve (m w : ℕ)
    (hf : (1 < w ∧ ¬ w.Prime) ∧ Odd (m * w) ∧ Nat.Coprime m w ∧
      ArithmeticFunction.sigma 1 m * (w + 1) = 2 * m * w)
    (hne : m * w ≠ 198585576189) : 10 ^ 12 < m := by sorry

end DescartesNumber
