module

public import Mathlib.NumberTheory.ArithmeticFunction.Misc

public section

namespace DescartesNumber

/-- Banks, Güloğlu, Nevans and Saidak's uniqueness theorem for cube-free
Descartes integers with at most six distinct prime divisors. -/
theorem descartes_cubeFree_lt_seven_primeFactors_unique (n : ℕ)
    (hd : ∃ m w : ℕ, n = m * w ∧ (1 < w ∧ ¬ w.Prime) ∧ Odd (m * w) ∧ Nat.Coprime m w ∧
      ArithmeticFunction.sigma 1 m * (w + 1) = 2 * m * w)
    (hcf : ∀ ⦃x : ℕ⦄, x ^ 3 ∣ n → IsUnit x) (hcard : n.primeFactors.card < 7) :
    n = 198585576189 := by sorry

end DescartesNumber
